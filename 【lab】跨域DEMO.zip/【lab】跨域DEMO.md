#【lab】跨域DEMO
XMLHttpRequest遵从同源策略,因此访问非同源的资源就会发生错误。
>所谓同源是指，域名，协议，端口相同。


##实验环境

nginx（port:80），wamp(port:81)
###解决方案1（老方法~）
------------------------------------------------
用scripts标签封装jsonp，
####客户端demo:
```javascript
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    CLIENT
    <script>
    function a(data) {
        console.log(JSON.stringify(data));
    }//相当于把function a传过去封装好参数再传回来执行
    </script>
    <script src="http://localhost:81/cors2/index.php?callback=a"></script>
</body>
</html>
```
####服务器demo:
```php
    $arr = array("a"=>1,"b"=>"hello");
    $res = json_encode($arr);

    if(isset($_GET['callback']) === TRUE) {
        header('Content-Type: text/javascript;');
        echo $_GET['callback']."(".$res.");";
    } else {
        echo "Error";
    }	
```
###解决方案2（CORS）
------------------------------------------------
##实验结果
###方法1
![Alt text](./1455550187938.png)
##遗留问题
1.windows下的nginx控制bat文件的编写。.2.15
2.nginx php运行环境没搭好。

**2016.2.15**

